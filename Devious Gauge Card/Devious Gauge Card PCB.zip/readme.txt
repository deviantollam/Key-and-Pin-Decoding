Gauge Card by Deviant Ollam - https://github.com/deviantollam/decoding
PCB Version by Andy Tait - http://rasteri.com

Source files are in Altium Circuitmaker - 
https://circuitmaker.com/Projects/Details/rasteri/Gauge-Card
